# ok-admin v1.0

一个很赞的，扁平化风格的，响应式布局的通用后台模版解决方案，旨为后端程序员减压！
![输入图片说明](https://images.gitee.com/uploads/images/2019/0525/161436_23cd5fd8_1152471.png "屏幕截图.png")

### QQ交流群

~~964222534~~ 🈵️ 、 ~~833539807~~ 🈵️ 、 797113469 🔥

# 技术栈

<p>
  <img src="https://img.shields.io/badge/layui-2.4.5-brightgreen.svg">
  <img src="https://img.shields.io/badge/zTree-3.5.40-brightgreen.svg">
  <img src="https://img.shields.io/badge/NProgress-0.2.0-brightgreen.svg">
  <img src="https://img.shields.io/badge/ECharts-2.0-brightgreen.svg">
  <img src="https://img.shields.io/badge/Animate.css-3.7.0-brightgreen.svg">
</p>

# 访问地址

- http://ok-admin-v1.xlbweb.cn
- http://ok-admin.xlbweb.cn

# 效果预览

<table>
    <tr>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161523_49e0eb96_1152471.png"/></td>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161620_a894f907_1152471.png"/></td>
    </tr>
    <tr>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161730_51a9c186_1152471.png"/></td>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161754_d382086c_1152471.png"/></td>
    </tr>
    <tr>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161830_f075d89f_1152471.png"/></td>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161853_a07554d7_1152471.png"/></td>
    </tr>
    <tr>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161912_c86d7db2_1152471.png"/></td>
        <td><img src="https://images.gitee.com/uploads/images/2019/0525/161939_ec3ef027_1152471.png"/></td>
    </tr>
</table>

# 开源协议

[MIT](https://github.com/bobi1234/ok-admin/blob/master/LICENSE)
