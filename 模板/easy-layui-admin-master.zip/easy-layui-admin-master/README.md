# easy-layui-admin
layui后端模板，layui后台管理模板，layui admin框架


## 效果截图

![alt text](images/screenshots.jpg "网站截图")


## 说明

1、基于Layui2.5.4，通用型后台管理模板系统

2、打开根目录下的index.html预览效果


## Bug及建议

如有Bug欢迎开Issues或者邮箱 277023115@qq.com 留言，如有好的建议以及意见也欢迎交流。

