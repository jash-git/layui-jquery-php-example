layui.config({
    base: './module/'
}).extend({
    treeSelect: 'treeSelect/treeSelect'
});